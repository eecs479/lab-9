from qiskit import *
from qiskit_aer import AerSimulator

from typing import Dict, List

def sim_and_calc_probs(qc: QuantumCircuit) -> float:
    """Takes quantum circuit with 2 qubits and 1 classical bit, with
    quantum bit in an unknown state.
    
    Simulates measurement of qubit 0 onto classical bit 0 1024 times and returns Pr(0)-Pr(1)"""
    pass

def estimate_x_comp(qc: QuantumCircuit) -> float:
    """Takes quantum circuit with 2 qubits and 1 classical bit, with
    quantum bit in an unknown state.
    
    Returns estimated X component of qubit by performing 1024 measurements"""

    pass

def estimate_y_comp(qc: QuantumCircuit) -> float:
    """Takes quantum circuit with 2 qubits and 1 classical bit, with
    quantum bit in an unknown state.
    
    Returns estimated Y component of qubit by performing 1024 measurements"""

    pass

def estimate_z_comp(qc: QuantumCircuit) -> float:
    """Takes quantum circuit with 2 qubits and 1 classical bit, with
    quantum bit in an unknown state.
    
    Returns estimated Z component of qubit by performing 1024 measurements"""
    
    pass

def get_comps(qc: QuantumCircuit) -> List[float]:
    """Takes quantum circuit with 2 qubits and 1 classical bit, with
    quantum bit in an unknown state.

    Returns estimated X,Y,Z components of qubit by performing 1024 measurements"""
    return [ estimate_x_comp(qc.copy()),
             estimate_y_comp(qc.copy()),
             estimate_z_comp(qc.copy())]












