from qiskit import *
from qiskit_aer import AerSimulator
from qiskit_aer.noise import *
from qiskit.circuit.gate import Gate
from qiskit.circuit.library import IGate
import numpy as np
from typing import Tuple, Dict
import sys


def run_sim(qc: QuantumCircuit, num_shots: int, model:NoiseModel) -> Dict[str, int]:
    sim = AerSimulator()
    result = sim.run(qc, shots=1000, noise_model=model, optimization_level=0).result()
    return result.get_counts()

# No need to modify this
def noisy_model(p_error: float) -> Tuple[Gate, NoiseModel]:
    """Returns a Gate and NoiseModel pair. If the NoiseModel is passed to
    the execute function, any instance of Gate will be insert a bit-flip
    with probability p_error, and a phase-flip also with probability p_error
    Args:
        p_error: How often the gate should introduce noise"""

    noise_gate = IGate(label="noise")

    bit_flip = pauli_error([('X', p_error), ('I', 1 - p_error)])
    phase_flip = pauli_error([('Z', p_error), ('I', 1 - p_error)])
    bitphase_flip = bit_flip.compose(phase_flip)

    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(bitphase_flip, noise_gate.label)

    return noise_gate, noise_model


def bitflip_code(noiseChannel: Gate) -> QuantumCircuit:
    """Returns quantum circuit implementing bit-flip code, placing noiseChannel
    on each qubit in between the entanglement step and the syndrome measurement
    Args:
        noiseChannel: Gate which will introduce errors probabilistically"""
    pass

def phaseflip_code(noiseChannel: Gate) -> QuantumCircuit:
    """Returns quantum circuit implementing phase-flip code, placing noiseChannel
    on each qubit in between the entanglement step and the syndrome measurement
    Args:
        noiseChannel: Gate which will introduce errors probabilistically"""
    pass

def get_error_rate(qc: QuantumCircuit, model: NoiseModel) -> float:
    """Runs simulations of qc with the provided noise model and returns
    how often measuring the starting code qubit gives the wrong value
    Args:
        qc: Circuit implementing code
        model: Noise model to use during simulation"""
    num_shots = 1000
    counts = run_sim(qc, num_shots, model)
    # process counts here
    
    
# you can run this code directly from your terminal to try different noise models
if __name__ == "__main__":
    prob = float(sys.argv[1])
    noise_channel, model = noisy_model(prob)
    qc = bitflip_code(noise_channel)
    rate = get_error_rate(qc.copy(), model)
    print("Individual bitflip rate: " + str(prob*100) + "% - after error correction: " + str(rate*100) + "%")

    qc = phaseflip_code(noise_channel)
    rate = get_error_rate(qc.copy(), model)
    print("Individual phaseflip rate: " + str(prob*100) + "% - after error correction: " + str(rate*100) + "%")