import numpy as np
import math
import unittest
from qiskit import *
from typing import Dict, List

import lab_4



class TestLab4(unittest.TestCase):
    THRESHOLD = .1

    def run_test(self, state: np.array, correct: List[float]):
        qc = QuantumCircuit(2,1)
        qc.initialize(state)
        estimates = lab_4.get_comps(qc)

        for test,correct in zip(estimates, correct):
            self.assertTrue(abs(test-correct) < self.THRESHOLD)

    def test_Z(self):
        # test along z-axis
        self.run_test([1,0,0,0], [0,0,1])
        self.run_test([0,0,1,0], [0,0,-1])

    def test_X(self):
        # test along x-axis
        self.run_test(1/np.sqrt(2)*np.array([1,0,1,0]), [1,0,0])
        self.run_test(1/np.sqrt(2)*np.array([1,0,-1,0]), [-1,0,0])

    def test_Y(self):
        # test along y-axis
        self.run_test(1/np.sqrt(2)*np.array([1,0,1j,0]), [0,1,0])
        self.run_test(1/np.sqrt(2)*np.array([1,0,-1j,0]), [0,-1,0])

    def test_general(self):
        # test general state
        state = [math.sqrt(.68),0, math.sqrt(.32)*np.exp(1.16j*math.pi),0]
        self.run_test(state, [-.82,-.45,.36])

if __name__ == "__main__":
	unittest.main()