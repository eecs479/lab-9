from qiskit import *
import unittest

import lab_9

class TestLab9(unittest.TestCase):
    def test_code(self):
        errors = [.6, .5, .1]
        expected_rates = [.648, .5, .028]
        for error, expected_rate in zip(errors, expected_rates):
            noise_channel, model = lab_9.noisy_model(error)
            qc = lab_9.bitflip_code(noise_channel)
            rate = lab_9.get_error_rate(qc.copy(), model)
            self.assertTrue(rate < expected_rate*1.2 and rate > expected_rate*.08)
            
            qc = lab_9.phaseflip_code(noise_channel)
            rate = lab_9.get_error_rate(qc.copy(), model)
            self.assertTrue(rate < expected_rate*1.2 and rate > expected_rate*.08)

if __name__ == "__main__":
	unittest.main()